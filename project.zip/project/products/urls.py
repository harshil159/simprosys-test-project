from django.urls import path
from rest_framework.authtoken import views
from rest_framework.routers import DefaultRouter

from products.views import *


router = DefaultRouter()

router.register('category', CategoryViewSet, basename='category')
router.register('product', ProductViewSet, basename='product')

urlpatterns = [
    path('user-auth/', views.obtain_auth_token, name='user-auth'),
    path('product/import/', ProductImportAPIView.as_view(), name='product-import'),
    path('product/export/', ProductExportAPIView.as_view(), name='product-export'),
]

urlpatterns += router.urls