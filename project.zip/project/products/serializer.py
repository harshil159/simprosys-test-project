from rest_framework import serializers

from products.models import (
    Category, Product
)


class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ('name',)


class ProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = '__all__'

    def validate(self, attrs):
        if not 'category' in attrs or attrs['category'] in [None, 'null', '']:
            raise serializers.ValidationError({'error': 'category is required'})
        return attrs
