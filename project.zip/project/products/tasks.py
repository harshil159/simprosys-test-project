import random
from celery import shared_task
from django.utils.crypto import get_random_string

from products.models import Product, Category


@shared_task(bind=True)
def generate_dummy_products(self, count=0):
    data_tobe_create = []

    for i in range(count):
        title = get_random_string(10).upper()

        category = Category.objects.first()

        data_tobe_create.append(
            Product(
                category=category,
                title=title,
                description=f"This is description of {title}",
                price=random.randint(1,1000),
                status=random.randint(1,2)
            )
        )

    Product.objects.bulk_create(data_tobe_create)
