from django.db import models
from django.conf import settings
from django.utils.translation import pgettext_lazy
from django.utils.translation import gettext_lazy as _
from django.db.models.signals import post_save
from django.dispatch import receiver
from rest_framework.authtoken.models import Token


class ProductStatusChoices(models.IntegerChoices):
    ACTIVE = 1, _('Active')
    INACTIVE = 2, _('Inactive')


class Base(models.Model):
    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name=pgettext_lazy('field', 'Created At')
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        verbose_name=pgettext_lazy('field', 'Updated At')
    )

    class Meta:
        abstract = True


class Category(models.Model):
    name = models.CharField(
        max_length=255,
        verbose_name=pgettext_lazy('field', 'Category Name'),
    )


class Product(Base):
    category = models.ForeignKey(
        Category,
        on_delete=models.CASCADE,
        verbose_name=pgettext_lazy('field', 'Category ID'),
        blank=True,
        null=True
    )
    title = models.CharField(
        max_length=255,
        verbose_name=pgettext_lazy('field', 'Title'),
    )
    description = models.TextField(
        verbose_name=pgettext_lazy('field', 'Description'),
    )
    price = models.DecimalField(
        max_digits=6,
        decimal_places=3,
        default=0,
        verbose_name=pgettext_lazy('field', 'Price'),
    )
    status = models.PositiveSmallIntegerField(
        choices=ProductStatusChoices.choices,
        default=ProductStatusChoices.ACTIVE,
        verbose_name=pgettext_lazy('field', 'Status'),
    )


@receiver(post_save, sender=settings.AUTH_USER_MODEL)
def generate_token(sender, instance=None, created=False, **kwargs):
    if created:
        Token.objects.create(user=instance)
