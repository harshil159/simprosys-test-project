from openpyxl import Workbook
from openpyxl.writer.excel import save_workbook
from rest_framework import filters, status
from rest_framework.permissions import IsAuthenticated
from rest_framework.mixins import CreateModelMixin
from rest_framework.viewsets import GenericViewSet, ModelViewSet
from rest_framework.views import APIView
from rest_framework.response import Response
from django.http import HttpResponse

from products.models import Category, Product, ProductStatusChoices
from products.serializer import CategorySerializer, ProductSerializer
from products.tasks import generate_dummy_products


class CategoryViewSet(CreateModelMixin, GenericViewSet):
    permission_classes = (IsAuthenticated,)
    serializer_class = CategorySerializer
    queryset = Category.objects.all()


class ProductViewSet(ModelViewSet):
    permission_classes = (IsAuthenticated,)
    serializer_class = ProductSerializer
    queryset = Product.objects.all()
    filter_backends = (filters.SearchFilter,)
    search_fields = ('title',)


class ProductImportAPIView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request):

        if 'count' not in request.data:
            return Response({
                'error': 'Please provide the number of dummy products to generate.'
            }, status=status.HTTP_400_BAD_REQUEST)

        if (not isinstance(request.data['count'], int)) or (request.data['count'] <= 0):
            return Response({
                'error': 'Please provide the positive number of dummy products to generate.'
            }, status=status.HTTP_400_BAD_REQUEST)

        generate_dummy_products.delay(count=request.data['count'])
        return Response({
            'success': True
        }, status=status.HTTP_200_OK)


class ProductExportAPIView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request):

        wb = Workbook()
        ws = wb.active

        ws.append(["Category", "Title", "Description", "Price", "Status"])

        products = Product.objects.all().select_related('category').values(
            'category__name', 'title', 'description', 'price', 'status'
        )

        for product in products:
            status = ProductStatusChoices(product['status']).label

            ws.append([
                product['category__name'],
                product['title'],
                product['description'],
                product['price'],
                str(status),
            ])

        response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        response['Content-Disposition'] = 'attachment; filename=products.xlsx'

        wb.save(response)

        return response
